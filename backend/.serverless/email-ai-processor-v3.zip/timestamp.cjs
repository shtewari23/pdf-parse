// timestamp.cjs
module.exports.now = () => {
  return Date.now().toString(); // e.g., 1749038016789
};
